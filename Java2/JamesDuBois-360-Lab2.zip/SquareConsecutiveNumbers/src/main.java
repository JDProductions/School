/**
 * Created by freddubois on 10/18/16.
 */
public class main {
    public static void main(String [] args)
    {
        ConsecutiveWindow window = new ConsecutiveWindow("Consecutive Numbers");
    }
}

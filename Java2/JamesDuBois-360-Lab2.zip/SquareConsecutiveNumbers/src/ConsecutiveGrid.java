/**
 * Created by freddubois on 10/18/16.
 */

import java.awt.GridLayout;
import javax.swing.JButton;



public class ConsecutiveGrid {
}

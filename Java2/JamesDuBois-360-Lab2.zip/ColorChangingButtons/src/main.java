/**
 * Created by freddubois on 10/19/16.
 */
public class main {
    public static void main(String [] args)
    {
        ColorChangeWindow window = new ColorChangeWindow("Name");


        window.IsWhiteButtonPressed();
        window.IsYellButtonPressed();

    }
}

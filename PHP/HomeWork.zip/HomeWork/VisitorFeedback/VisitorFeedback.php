<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
	$Dir = "comments";
if (is_dir($Dir)) {
$CommentFiles = scandir($Dir);
foreach ($CommentFiles as $FileName) {
if (($FileName != ".") && ($FileName !=
"..")) {
echo "From <strong>$FileName</
strong><br />";
echo "<pre>\n";
$Comment = file_get_contents
($Dir . "/" .
$FileName);
echo $Comment;
echo "</pre>\n";
echo "<hr />\n";
}
}
}
?>
</body>
</html>
<?php

$filename='Result/png';
@header("Content-type: image/png");
@header("Content-Disposition: attachment; filename=$filename");
echo file_get_contents('attachment.zip');
?>